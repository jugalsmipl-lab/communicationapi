// services/store.js
// Simple in-memory log — persists across requests during uptime
// On Render free tier, logs reset on redeploy (acceptable for daily ops)

const logs = [];       // all WA send attempts
const ndrCases = [];   // active NDR cases

function addLog(entry) {
  logs.unshift({ ...entry, ts: new Date().toISOString() });
  if (logs.length > 2000) logs.pop();
}

function getLogs(limit = 200) {
  return logs.slice(0, limit);
}

function addNDR(entry) {
  const existing = ndrCases.findIndex(n => n.orderId === entry.orderId);
  if (existing >= 0) {
    ndrCases[existing] = { ...ndrCases[existing], ...entry, updatedAt: new Date().toISOString(), attempts: (ndrCases[existing].attempts || 1) + 1 };
  } else {
    ndrCases.unshift({ ...entry, ts: new Date().toISOString(), status: 'pending', attempts: 1 });
  }
}

function getNDRCases(statusFilter) {
  if (!statusFilter || statusFilter === 'all') return ndrCases;
  return ndrCases.filter(n => n.status === statusFilter);
}

function updateNDR(orderId, status) {
  const idx = ndrCases.findIndex(n => n.orderId === orderId);
  if (idx >= 0) ndrCases[idx].status = status;
  return idx >= 0;
}

function getStats() {
  const total = logs.length;
  const sent = logs.filter(l => l.success).length;
  const failed = logs.filter(l => !l.success).length;
  const ndrOpen = ndrCases.filter(n => n.status === 'pending').length;
  const byEvent = {};
  logs.forEach(l => { byEvent[l.event] = (byEvent[l.event] || 0) + 1; });
  return { total, sent, failed, ndrOpen, byEvent };
}

module.exports = { addLog, getLogs, addNDR, getNDRCases, updateNDR, getStats };
