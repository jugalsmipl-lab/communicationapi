// services/interakt.js
// Sends WhatsApp messages via Interakt API

const axios = require('axios');

const TEMPLATES = {
  order_placed:   process.env.TPL_ORDER_PLACED   || 'lc_order_placed',
  order_packed:   process.env.TPL_ORDER_PACKED   || 'lc_order_packed',
  order_shipped:  process.env.TPL_ORDER_SHIPPED  || 'lc_order_shipped',
  order_ofd:      process.env.TPL_ORDER_OFD      || 'lc_out_for_delivery',
  order_delivered:process.env.TPL_ORDER_DELIVERED|| 'lc_order_delivered',
  order_ndr:      process.env.TPL_ORDER_NDR      || 'lc_delivery_failed',
  order_return:   process.env.TPL_ORDER_RETURN   || 'lc_return_initiated',
};

// Clean mobile: strip country code, keep last 10 digits
function cleanMobile(raw) {
  const digits = String(raw).replace(/\D/g, '');
  return digits.slice(-10);
}

/**
 * sendWhatsApp({ event, customerName, mobile, orderId, storeName, trackingId, reason })
 * event: one of order_placed | order_packed | order_shipped | order_ofd | order_delivered | order_ndr | order_return
 */
async function sendWhatsApp(params) {
  const { event, customerName, mobile, orderId, storeName, trackingId = '', reason = 'Unable to reach' } = params;

  const templateName = TEMPLATES[event];
  if (!templateName) throw new Error(`Unknown event: ${event}`);

  const phone = cleanMobile(mobile);
  if (phone.length !== 10) throw new Error(`Invalid mobile: ${mobile}`);

  // Build body values per template
  const bodyMap = {
    order_placed:    [customerName, orderId, storeName],
    order_packed:    [customerName, orderId, storeName],
    order_shipped:   [customerName, orderId, storeName, trackingId],
    order_ofd:       [customerName, orderId, storeName],
    order_delivered: [customerName, orderId, storeName],
    order_ndr:       [customerName, orderId, storeName, reason],
    order_return:    [customerName, orderId, storeName],
  };

  const payload = {
    countryCode: '+91',
    phoneNumber: phone,
    callbackData: `${event}_${orderId}`,
    type: 'Template',
    template: {
      name: templateName,
      languageCode: 'en',
      bodyValues: bodyMap[event],
    },
  };

  try {
    const res = await axios.post(
      'https://api.interakt.ai/v1/public/message/',
      payload,
      {
        headers: {
          Authorization: process.env.INTERAKT_API_KEY,
          'Content-Type': 'application/json',
        },
        timeout: 10000,
      }
    );
    console.log(`[WA] SENT ${event} → ${phone} | order ${orderId} | result:`, res.data?.result);
    return { success: true, data: res.data };
  } catch (err) {
    const msg = err.response?.data || err.message;
    console.error(`[WA] FAILED ${event} → ${phone} | order ${orderId}:`, msg);
    return { success: false, error: msg };
  }
}

module.exports = { sendWhatsApp, TEMPLATES };
