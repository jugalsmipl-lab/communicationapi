// routes/courier.js
// Handles status webhooks from Shiprocket, Delhivery, Ecom Express, or any courier

const express = require('express');
const { sendWhatsApp } = require('../services/interakt');
const { addLog, addNDR } = require('../services/store');

const router = express.Router();

// ---- Status normaliser ----
// Maps each courier's status strings → our internal event key
function normaliseStatus(raw = '') {
  const s = raw.toUpperCase().replace(/[_\-\s]+/g, '_');

  if (/PLACED|BOOKED|CREATED/.test(s))          return 'order_placed';
  if (/PACKED|MANIFESTED|PICKUP_COMPLETE/.test(s)) return 'order_packed';
  if (/SHIPPED|IN_TRANSIT|DISPATCHED|PICKED/.test(s)) return 'order_shipped';
  if (/OUT_FOR_DELIVERY|OFD/.test(s))           return 'order_ofd';
  if (/DELIVERED|DEL$/.test(s))                 return 'order_delivered';
  if (/NDR|UNDELIVERED|DELIVERY_FAILED|FAILED_DELIVERY|NOT_DELIVERED|RTO_INITIATED/.test(s)) return 'order_ndr';
  if (/RETURN|RTO|REVERSE/.test(s))             return 'order_return';
  return null;
}

// ---- Shiprocket payload parser ----
function parseShiprocket(body) {
  return {
    orderId:      body.order_id || body.awb,
    mobile:       body.customer_phone || body.phone,
    customerName: body.customer_name || 'Customer',
    status:       body.current_status || body.status,
    trackingId:   body.awb || '',
    reason:       body.remark || body.reason || '',
    storeName:    body.company_name || 'London Cotton',
  };
}

// ---- Delhivery payload parser ----
function parseDelhivery(body) {
  const pkg = body.packages?.[0] || body;
  return {
    orderId:      pkg.refnum || pkg.waybill,
    mobile:       pkg.consignee_mobile || pkg.phone,
    customerName: pkg.consignee || 'Customer',
    status:       pkg.status || pkg.scan_type,
    trackingId:   pkg.waybill || '',
    reason:       pkg.remarks || '',
    storeName:    'London Cotton',
  };
}

// ---- Ecom Express payload parser ----
function parseEcom(body) {
  return {
    orderId:      body.order_number || body.awb_number,
    mobile:       body.consignee_mobile,
    customerName: body.consignee_name || 'Customer',
    status:       body.status,
    trackingId:   body.awb_number || '',
    reason:       body.remarks || '',
    storeName:    'London Cotton',
  };
}

// ---- Generic parser (fallback) ----
function parseGeneric(body) {
  return {
    orderId:      body.order_id || body.orderId || body.awb,
    mobile:       body.phone || body.mobile || body.customer_phone,
    customerName: body.name || body.customer_name || 'Customer',
    status:       body.status || body.current_status,
    trackingId:   body.tracking_id || body.awb || '',
    reason:       body.reason || body.remarks || '',
    storeName:    body.store || 'London Cotton',
  };
}

// Detect courier from headers or query param
function detectCourier(req) {
  const ua = (req.headers['user-agent'] || '').toLowerCase();
  const q  = (req.query.courier || '').toLowerCase();
  if (q.includes('shiprocket') || ua.includes('shiprocket')) return 'shiprocket';
  if (q.includes('delhivery')  || ua.includes('delhivery'))  return 'delhivery';
  if (q.includes('ecom'))                                     return 'ecom';
  return 'generic';
}

// POST /courier/webhook?courier=shiprocket  (or delhivery / ecom / generic)
router.post('/webhook', express.json(), async (req, res) => {
  const body    = req.body;
  const courier = detectCourier(req);

  let parsed;
  if (courier === 'shiprocket') parsed = parseShiprocket(body);
  else if (courier === 'delhivery') parsed = parseDelhivery(body);
  else if (courier === 'ecom') parsed = parseEcom(body);
  else parsed = parseGeneric(body);

  const { orderId, mobile, customerName, status, trackingId, reason, storeName } = parsed;

  if (!orderId || !mobile) {
    console.warn('[Courier] Missing orderId or mobile', body);
    return res.status(200).json({ skipped: 'missing fields' });
  }

  const event = normaliseStatus(status);
  if (!event) {
    console.log(`[Courier] Unrecognised status "${status}" for order ${orderId} — skipped`);
    return res.status(200).json({ skipped: `unrecognised status: ${status}` });
  }

  // If NDR, track it separately
  if (event === 'order_ndr') {
    addNDR({ orderId: String(orderId), mobile, customerName, reason, courier, storeName });
  }

  const result = await sendWhatsApp({ event, customerName, mobile, orderId: String(orderId), storeName, trackingId, reason });
  addLog({ event, orderId: String(orderId), mobile, store: storeName, courier, ...result });

  res.status(200).json({ ok: true, event });
});

module.exports = router;
