// routes/ndr.js
// Manual NDR Excel upload + NDR case management API

const express = require('express');
const multer  = require('multer');
const XLSX    = require('xlsx');
const { sendWhatsApp } = require('../services/interakt');
const { addLog, addNDR, getNDRCases, updateNDR } = require('../services/store');

const router  = express.Router();
const upload  = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

// GET /ndr/cases?status=pending|resolved|all
router.get('/cases', (req, res) => {
  const cases = getNDRCases(req.query.status || 'all');
  res.json(cases);
});

// POST /ndr/update — mark NDR resolved or schedule retry
router.post('/update', express.json(), (req, res) => {
  const { orderId, status } = req.body; // status: resolved | retry | rto
  if (!orderId || !status) return res.status(400).json({ error: 'orderId and status required' });
  const ok = updateNDR(orderId, status);
  res.json({ ok });
});

// POST /ndr/resend — manually resend WhatsApp to one NDR customer
router.post('/resend', express.json(), async (req, res) => {
  const { orderId, mobile, customerName, reason, storeName } = req.body;
  if (!orderId || !mobile) return res.status(400).json({ error: 'orderId and mobile required' });
  const result = await sendWhatsApp({
    event: 'order_ndr',
    customerName: customerName || 'Customer',
    mobile, orderId, storeName: storeName || 'London Cotton', reason: reason || '',
  });
  addLog({ event: 'order_ndr', orderId, mobile, store: storeName, manual: true, ...result });
  res.json(result);
});

// POST /ndr/upload — upload daily OFD/NDR Excel file
router.post('/upload', upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  let rows;
  try {
    const wb = XLSX.read(req.file.buffer, { type: 'buffer' });
    rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: '' });
  } catch {
    return res.status(400).json({ error: 'Invalid Excel file' });
  }

  // Column name aliases (handles variations in headings)
  function col(row, ...keys) {
    for (const k of keys) {
      const found = Object.keys(row).find(r => r.toLowerCase().replace(/\s+/g,'').includes(k.toLowerCase().replace(/\s+/g,'')));
      if (found && row[found]) return String(row[found]);
    }
    return '';
  }

  const STATUS_MAP = {
    'OFD': 'order_ofd', 'OUT FOR DELIVERY': 'order_ofd', 'OUTFORDELIVERY': 'order_ofd',
    'PACKED': 'order_packed', 'PACK': 'order_packed',
    'SHIPPED': 'order_shipped', 'DISPATCHED': 'order_shipped',
    'DELIVERED': 'order_delivered',
    'UNDELIVERED': 'order_ndr', 'NDR': 'order_ndr', 'FAILED': 'order_ndr', 'NOT DELIVERED': 'order_ndr',
    'RETURN': 'order_return', 'RTO': 'order_return',
  };

  function getEvent(rawStatus) {
    const s = (rawStatus || '').toUpperCase().trim();
    for (const [key, val] of Object.entries(STATUS_MAP)) {
      if (s.includes(key)) return val;
    }
    return null;
  }

  const results = [];
  for (const row of rows) {
    const mobile       = col(row, 'mobile', 'phone', 'contact');
    const customerName = col(row, 'customername', 'name', 'customer');
    const orderId      = col(row, 'orderid', 'order', 'awb');
    const rawStatus    = col(row, 'deliverystatus', 'status', 'current');
    const reason       = col(row, 'reason', 'remark', 'ndr');
    const storeName    = col(row, 'store', 'shop') || 'London Cotton';
    const event        = getEvent(rawStatus);

    if (!mobile || !orderId || !event) {
      results.push({ orderId, mobile, status: rawStatus, result: 'skipped', reason: 'missing data or unknown status' });
      continue;
    }

    if (event === 'order_ndr') addNDR({ orderId, mobile, customerName, reason, storeName });

    const r = await sendWhatsApp({ event, customerName, mobile, orderId, storeName, reason });
    addLog({ event, orderId, mobile, store: storeName, ...r });
    results.push({ orderId, mobile, event, ...r });

    // small delay to avoid rate limiting
    await new Promise(resolve => setTimeout(resolve, 150));
  }

  const sent    = results.filter(r => r.success).length;
  const failed  = results.filter(r => r.success === false).length;
  const skipped = results.filter(r => r.result === 'skipped').length;

  res.json({ total: rows.length, sent, failed, skipped, results });
});

module.exports = router;
