// routes/shopify.js
// Handles webhooks from Shopify for londoncotton.in and frankshop.com

const express = require('express');
const crypto = require('crypto');
const { sendWhatsApp } = require('../services/interakt');
const { addLog } = require('../services/store');

const router = express.Router();

function verifyShopifyHmac(req, secret) {
  const hmac = req.headers['x-shopify-hmac-sha256'];
  if (!hmac || !secret) return true; // skip if not configured
  const hash = crypto
    .createHmac('sha256', secret)
    .update(req.rawBody || '')
    .digest('base64');
  return hash === hmac;
}

function getStoreConfig(req) {
  const domain = req.headers['x-shopify-shop-domain'] || '';
  if (domain.includes('frankshop')) {
    return { name: 'FrankShop', secret: process.env.FS_SHOPIFY_WEBHOOK_SECRET };
  }
  return { name: 'London Cotton', secret: process.env.LC_SHOPIFY_WEBHOOK_SECRET };
}

// Map Shopify topic → our event key
function topicToEvent(topic) {
  const map = {
    'orders/create':    'order_placed',
    'orders/fulfilled': 'order_shipped',
    'orders/cancelled': null,
    'fulfillments/create': 'order_shipped',
    'refunds/create':   'order_return',
  };
  return map[topic] || null;
}

router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const store = getStoreConfig(req);
  const topic = req.headers['x-shopify-topic'];

  if (!verifyShopifyHmac(req, store.secret)) {
    return res.status(401).json({ error: 'Invalid HMAC' });
  }

  let body;
  try {
    body = JSON.parse(req.body.toString());
  } catch {
    return res.status(400).json({ error: 'Bad JSON' });
  }

  const event = topicToEvent(topic);
  if (!event) return res.status(200).json({ skipped: true });

  // Extract customer info from Shopify order payload
  const customer = body.customer || {};
  const shipping = body.shipping_address || body.billing_address || {};
  const phone = customer.phone || shipping.phone || body.phone || '';
  const name = customer.first_name
    ? `${customer.first_name} ${customer.last_name || ''}`.trim()
    : shipping.name || 'Customer';
  const orderId = body.order_number || body.name || body.id;
  const trackingId = body.fulfillments?.[0]?.tracking_number || '';

  if (!phone) {
    console.warn(`[Shopify] No phone for order ${orderId}`);
    return res.status(200).json({ skipped: 'no phone' });
  }

  const result = await sendWhatsApp({
    event,
    customerName: name,
    mobile: phone,
    orderId: String(orderId),
    storeName: store.name,
    trackingId,
  });

  addLog({ event, orderId: String(orderId), mobile: phone, store: store.name, ...result });
  res.status(200).json({ ok: true });
});

module.exports = router;
