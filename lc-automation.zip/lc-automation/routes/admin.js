// routes/admin.js
// REST API endpoints for the dashboard

const express = require('express');
const { getLogs, getStats } = require('../services/store');

const router = express.Router();

// Simple password check middleware
function auth(req, res, next) {
  const pass = req.headers['x-admin-password'] || req.query.pwd;
  if (process.env.ADMIN_PASSWORD && pass !== process.env.ADMIN_PASSWORD) {
    // For dashboard (browser), allow GET without auth — protect POST/sensitive via env
    if (req.method !== 'GET') return res.status(401).json({ error: 'Unauthorised' });
  }
  next();
}

router.get('/stats', auth, (req, res) => {
  res.json(getStats());
});

router.get('/logs', auth, (req, res) => {
  const limit = parseInt(req.query.limit) || 200;
  res.json(getLogs(limit));
});

module.exports = router;
