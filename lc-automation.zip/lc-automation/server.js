// server.js — London Cotton / FrankShop WhatsApp Automation Server
require('dotenv').config();

const express = require('express');
const path    = require('path');
const cron    = require('node-cron');

const shopifyRouter = require('./routes/shopify');
const courierRouter = require('./routes/courier');
const ndrRouter     = require('./routes/ndr');
const adminRouter   = require('./routes/admin');

const app  = express();
const PORT = process.env.PORT || 3000;

// Save raw body for Shopify HMAC verification
app.use((req, res, next) => {
  let data = '';
  req.on('data', chunk => { data += chunk; });
  req.on('end', () => { req.rawBody = data; next(); });
});

// Serve admin dashboard
app.use(express.static(path.join(__dirname, 'dashboard/public')));

// Routes
app.use('/shopify', shopifyRouter);
app.use('/courier', courierRouter);
app.use('/ndr',     ndrRouter);
app.use('/api',     adminRouter);

// Health check — Render pings this to keep the service alive
app.get('/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString(), service: 'LC WA Automation' });
});

// Root → dashboard
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'dashboard/public/index.html'));
});

// Cron: self-ping every 14 min to prevent Render free tier sleep
if (process.env.RENDER_EXTERNAL_URL) {
  cron.schedule('*/14 * * * *', async () => {
    try {
      const https = require('https');
      https.get(process.env.RENDER_EXTERNAL_URL + '/health', () => {});
      console.log('[CRON] Self-ping sent');
    } catch (e) {}
  });
}

app.listen(PORT, () => {
  console.log(`\n✅ LC WhatsApp Automation running on port ${PORT}`);
  console.log(`   Dashboard: http://localhost:${PORT}`);
  console.log(`   Shopify webhook: http://localhost:${PORT}/shopify/webhook`);
  console.log(`   Courier webhook: http://localhost:${PORT}/courier/webhook?courier=shiprocket`);
  console.log(`   NDR upload:      http://localhost:${PORT}/ndr/upload\n`);
});
